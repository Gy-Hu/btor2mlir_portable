/* THIS IS A GENERATED FILE */
/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

#ifndef _NSSCKFT_H_
#define _NSSCKFT_H_ 1

#include "pkcs11t.h"

#endif /* _NSSCKFT_H_ */
